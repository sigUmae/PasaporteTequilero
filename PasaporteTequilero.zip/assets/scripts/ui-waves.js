+function ($) {

  $(function(){

      Waves.attach('.btn');
      Waves.attach('[md-ink-ripple]');
      Waves.init();

  });
}(jQuery);
