<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8" />
    <title>Pasaporte tequilero</title>
    <meta name="description" content="app, web app, responsive, responsive layout, admin, admin panel, admin dashboard, flat, flat ui, ui kit, AngularJS, ui route, charts, widgets, components" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="stylesheet" href="<?php base_url('assets/libs/assets/animate.css/animate.css')?>" type="text/css" />
    <link rel="stylesheet" href="<?php base_url('assets/libs/assets/font-awesome/css/font-awesome.css')?>" type="text/css" />
    <link rel="stylesheet" href="../libs/jquery/bootstrap/dist/css/bootstrap.css" type="text/css" />
    <link rel="stylesheet" href="../libs/jquery/waves/dist/waves.css" type="text/css" />

    <link rel="stylesheet" href="styles/material-design-icons.css" type="text/css" />
    <link rel="stylesheet" href="styles/font.css" type="text/css" />
    <link rel="stylesheet" href="styles/app.css" type="text/css" />
</head>
<body>