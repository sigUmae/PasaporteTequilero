<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Payu_lib {

	function __construct(){
	    require_once 'lib_payu/PayU.php';
	}
	
}